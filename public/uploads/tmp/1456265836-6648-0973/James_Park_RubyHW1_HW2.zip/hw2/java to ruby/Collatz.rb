# James Park
# Ruby on Rails HW2

class Pair

attr_reader :first, :second

	def initialize(first, second)
      @first = first
      @second = second
	end

	def to_s
		"(#{@first}, #{@second})"
	end
end

class Collatz

	def simple_compute_sequence_lengths(n)
		if n < 0 
			raise ArgumentError
		end
		array = Array.new
		array << 0
		for i in 1..n 
			array << length_of_sequence(i)
		end
		array
	end

	def memoized_length_of_sequence(n, array)
		if n < 0 or array == nil
			raise ArgumentError
		end
		i = 1
		j = n
		while n != 1
			if n < j
				m = i + array[n] - 1
				return m
			end
			if n % 2 == 0 
				n = n /2
			else
				n = 3 * n + 1
			end
			i = i + 1  
		end
		i
	end

	def memoized_compute_sequence_lengths(n)
		if n < 0 
			raise ArgumentError
		end
		array = Array.new(n + 1, 0)
		for i in 1..n + 1
			array[i] = memoized_length_of_sequence(i, array)
		end
		array
	end

   	def collatz_1(n)
		if n < 0 
			raise ArgumentError
		end
		if n == 1 
			return 1
		end
		if n % 2 == 0 
			i = n / 2
		else 
			i = 3 * n + 1
		return i
		end
	end

	def sequence_of(n)
		if n <= 0
			raise ArgumentError
		end
		array = Array.new
		array << n
		while n != 1
			if n % 2 == 0 
				n = n / 2
			else
				n = 3 * n + 1
			end
			array << n
		end
		array
	end

	def length_of_sequence(n)
		if n <= 0 
			raise ArgumentError
		end
		counter = 1
		while n != 1
			if n % 2 == 0
				n = n/2
			else
				n = 3 * n + 1
			end
			counter += 1	
		end
		counter
	end

	def largest_value_in_sequence(n)
		if n <= 0 
			raise ArgumentError
		end
		sequence_of(n).max
	end

	def equal_length_twins(lo, hi)
		array = Array.new
		for i in lo..hi + 1
			if length_of_sequence(i) == length_of_sequence(i + 1)
 				array << Pair.new(i, length_of_sequence(i))
			end
		end
		array
	end

	def equal_max_value_twins(lo, hi)
		array = Array.new
		for i in lo..hi + 1
			j = largest_value_in_sequence(i)
			k = largest_value_in_sequence(i + 1)
			if j == k
				array << Pair.new(i, j)
			end
		end
		array
	end

	def occurrences(n, counts)
		if n < 0 
			raise ArgumentError
		end
		array = Array.new(counts + 1, 0)
		for i in 1..n
			sequence_of(i).each do |item| 
				if item <= counts
					array[item] = array[item] + 1
				end
			end
		end
		array
	end

	def odd_occurrences(n, counts)
		if n < 0 
			raise ArgumentError
		end
		array = Array.new(counts + 1, 0)
		for i in 1..counts
			counter = 0
			sequence_of(i).each do |item|
				if item % 2 != 0
					counter = counter + 1
				end
			end
			array[i] = counter
		end
		array
	end

	def do_timings(n)
		if n < 0 
			raise ArgumentError
		end

	end
end

def main
  collatz = Collatz.new
  for n in 1..100
    puts "Length is #{collatz.length_of_sequence(n)}."
    puts "Max number is #{collatz.largest_value_in_sequence(n)}."
  end

    puts "List of equal length twins is "
    puts collatz.equal_length_twins(1, 100)
 
    puts "List of equal max value twins is "
    puts collatz.equal_max_value_twins(1, 100)

    puts "List of occurrences is #{collatz.occurrences(100, 100)}"
    puts "List of odd occurrences #{collatz.odd_occurrences(100, 100)}"
end

main