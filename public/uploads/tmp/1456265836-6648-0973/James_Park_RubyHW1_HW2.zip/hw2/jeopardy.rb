# James Park
# CIS 597 - HW2

require 'certified'
require 'nokogiri'
require 'open-uri'

Main_page = "https://www.cia.gov/library/publications/the-world-factbook/print/textversion.html"

Temp_country_url = "https://www.cia.gov/library/publications/the-world-factbook/geos/countrytemplate_" # + code + ".html"

class Country 
	attr_reader :name, :code, :region, :population 
	attr_writer :name, :code, :region, :population

	def initialize(name, code, region, population)
      @name = name
      @code = code
      @region = region
      @population = population
	end

	def to_s
		"#{@name}"
	end
end

class Factbook
	def create_countries
		countries = Array.new 					#array of countries
		doc = Nokogiri::HTML(open(Main_page))

		doc.css("option").each do |row|
			temp = row["value"].split("/")[2]  	#get country name and country code 
			if temp == nil
				next
			end
			temp_code = row["value"].split("/")[2].split(".")[0]
			countries.push(Country.new(row.content.strip, temp_code, "world", "0"))
		end
		return countries
	end

	def fill_populations(countries)

		population_page = "https://www.cia.gov/library/publications/resources/the-world-factbook/rankorder/2119rank.html"

		doc = Nokogiri::HTML(open(population_page))
		
		doc.css("tr").each do |row|
			temp_country = /([a-zA-Z\s,'()-])+/.match(row.content)
			temp_population = /\d+[a-zA-Z\s,'()-]*([\d,]+)/.match(row.content)
			if((temp_population != nil) and (temp_country != nil))
				countries.each do |country|
  				  	if (temp_country[0] == country.name)
  						country.population = temp_population[1]
  					end
  				end
  			end
		end
		return countries
	end

	def fill_regions(countries)
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			doc.css("img").each do |row|
				temp_region = row["region"]
				if(temp_region != nil)
					country.region = temp_region
				end
			end
		end
		return countries
	end

	def fill_regions(countries)
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			doc.css("img").each do |row|
				temp_region = row["region"]
				if(temp_region != nil)
					country.region = temp_region
				end
			end
		end
		return countries
	end

	def find_hemisphere(countries, location)
		hemisphere = Array.new
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			doc.css('a[title="Notes and Definitions: Geographic coordinates"]').each do |row|
				temp1 = nil
				temp2 = nil

				temp1 = /[A-Z]/.match(row.parent.parent.parent.next.next.content.split[2])
				temp2 = /[A-Z]/.match(row.parent.parent.parent.next.next.content.split[5])
				
				if temp1 != nil 
					temp1 = temp1[0]
				end
				if temp2 != nil
					temp2 = temp2[0]
				end

				if(location == 'northern')
					if temp1 == 'N'
						hemisphere.push(country)
					end
				elsif(location == 'southern')
					if temp1 == 'S'
						hemisphere.push(country)
					end
				elsif(location == 'eastern')
					if temp2 == 'E'
						hemisphere.push(country)
					end
				elsif(location == 'western')
					if temp2 == 'W'
						hemisphere.push(country)
					end
				elsif(location == 'northeastern')
					if temp1 == 'N' && temp2 == 'E'
						hemisphere.push(country)
					end
				elsif(location == 'northwestern')
					if temp1 == 'N' && temp2 == 'W'
						hemisphere.push(country)
					end
				elsif(location == 'southeastern')
					if temp1 == 'S' && temp2 == 'E'
						hemisphere.push(country)
					end
				elsif(location == 'southwestern')
					if temp1 == 'S' && temp2 == 'W'
						hemisphere.push(country)
					end
				else
					return nil
				end
			end
		end
		return hemisphere
	end	

	def find_countries_attr(countries, region, attribute)
		countries_attr = Array.new

		countries.each do |country|
			if (country.region == region)
				page = Temp_country_url + country.code + ".html"

				doc = Nokogiri::HTML(open(page))

				doc.css("div[class=category_data]").each do |row|
					if (row.content.match(attribute) != nil)
						countries_attr.push(country)
					end
				end
			end
		end
		return countries_attr
	end

	def find_country_low_elevation(countries, region)
		countries_low = Array.new
		lowest_elevation = 100
		elevation_page = 'https://www.cia.gov/library/publications/the-world-factbook/fields/2020.html'

		doc = Nokogiri::HTML(open(elevation_page))

		#find lowest elevation in region
		countries.each do |country| 
			if (country.region == region)
				doc.css("tr[id=#{country.code}]").each do |row|
					temp = /\W[-?\d+,]+/.match(row.content)
					if(temp[0].strip.delete(',').to_i < lowest_elevation)
						lowest_elevation = temp[0].strip.delete(',').to_i
					end
				end
			end
		end

		#find countries with lowest elevantion
		countries.each do |country| 
			if (country.region == region)
				doc.css("tr[id=#{country.code}]").each do |row|
					temp = /\W[-?\d+,]+/.match(row.content)
					if(temp[0].strip.delete(',').to_i == lowest_elevation)
						countries_low.push(country)
					end
				end
			end
		end
		return countries_low
	end

	def find_political(countries, num, region)
		countries_poli = Array.new
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			counter = 0
			doc.css('div[class=category_data]').each do |row|
				if /Party/.match(row.content)
					counter += 1
				end
			end
			if counter > num 
				if region == "Asia"
					if country.region == "Central Asia" || country.region == "East and Southeast Asia" || country.region == "Middle East" || country.region == "South Asia"				
						countries_poli.push(country)
					end
				end
				if region != "Asia"
					if country.region == region
						countries_poli.push(country)
					end
				end
			end
		end
		return countries_poli
	end

	def find_electric_consump_capita(countries, num)
		temp_hash = Hash.new

		countries.each do |country|
			temp_array = Array.new
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			doc.css('div[class=category_data]').each do |row|
				temp = /(\d+.\d+ (billion|trillion) kWh)/.match(row.content)
	
				if temp != nil 
					temp_array.push(temp[1])
				end
			end
			target = temp_array[1]
			if target != nil
				temptarget = target.split(/\s/)
				temp = temptarget[0]
				if temptarget[1] == "billion"
					final_num = (temp.to_f * 1000000000)
				elsif temptarget[1] == "trillion"
					final_num = (temp.to_f * 1000000000000)
				elsif temptarget[1] == "million"
					final_num = (temp.to_f * 1000000)
				end
				per_capita= final_num.to_f / country.population.to_f 

				temp_hash[country.name] = per_capita
			end
		end
		temp_hash = temp_hash.sort_by{ |country, value| value.to_f}
		final_array = Array.new
		for i in 0..num-1
			final_array.push(temp_hash[i])
		end
		return final_array
	end

	def find_religion_more(countries, num)
		temp_array = Array.new
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			maj_religion = nil
			percentage = nil
			doc.css('a[title = "Notes and Definitions: Religions"]').each do |row|
				temp = row.parent.parent.parent.next.next.content.strip
				temp = /\w+ \d+.\d+%/.match(temp)
				if temp != nil 
					temp = temp[0]
					maj_religion = temp.split(/\s/)[0]
					percentage = temp.split(/\s/)[1]
				end
			end
			if percentage != nil && percentage.to_i > num
				temp_array.push("#{country.name}, #{maj_religion}, #{percentage}")
			end
		end
		return temp_array
	end

	def find_religion_less(countries, num)
		temp_array = Array.new
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			maj_religion = nil
			percentage = nil
			doc.css('a[title = "Notes and Definitions: Religions"]').each do |row|
				temp = row.parent.parent.parent.next.next.content.strip
				temp = /\w+ \d+.\d+%/.match(temp)
				if temp != nil 
					temp = temp[0]
					maj_religion = temp.split(/\s/)[0]
					percentage = temp.split(/\s/)[1]
				end
			end
			if percentage != nil && percentage.to_i < num
				temp_array.push("#{country.name}, #{maj_religion}, #{percentage}")
			end
		end
		return temp_array
	end

	def find_landlocked(countries)
		temp_array = []
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"			
			doc = Nokogiri::HTML(open(page))
			doc.css('a[title = "Notes and Definitions: Land boundaries"]').each do |row|
				temp0 = row.parent.parent.parent.next.next.content.delete("\t").strip.gsub("\n", "").split(" ")
				temp1 = nil	
				
					if temp0.length.to_i < 8  #being more than 7 indicates more than one border country
						temp1 = row.parent.parent.parent.parent.content.strip
						temp1 = /landlocked/.match(temp1)
					end		

				if temp1 != nil
					temp2 = row.parent.parent.parent.next.next.content.delete("\t").strip
					temp2 = temp2.split("\n")[7]
					if temp2 != nil 
						temp3 = temp2.gsub(/\d+/, "")
						if temp3 != nil 
							temp4 = temp3.gsub(/km/, "").strip	
							if temp4 != nil
								temp4 = temp4.delete(".").strip
								temp_array << "#{country.name}, #{temp4}"			
							end
						end
					end
				end
			end
		end
		return temp_array
	end



	def find_language(countries, language)
		temp_array = Array.new
		countries.each do |country|
			page = Temp_country_url + country.code + ".html"
			doc = Nokogiri::HTML(open(page))
			doc.css('a[title = "Notes and Definitions: Languages"]').each do |row|
				temp = /#{language}/.match(row.parent.parent.parent.next.next.content)
				if temp != nil
					temp_array.push(country.name)
				end
			end
		end
		return temp_array
	end
end

def main 
	#initializing our array of countries
	factbook = Factbook.new
	countries = factbook.create_countries
	countries =	factbook.fill_populations(countries)
	countries = factbook.fill_regions(countries)

	#find countries in South America prone to earthquakes
#	countries_attr = factbook.find_countries_attr(countries, "South America", "earthquakes") 
#	countries_attr.each do |country|
#		p country.to_s
#	end

	#find country with lowest elevation point in Europe
#	countries_low = factbook.find_country_low_elevation(countries, "Europe")
#	countries_low.each do |country|
#		p country.to_s
#	end

	#list all countries in southeastern hemisphere
#	countries_southeast = factbook.find_hemisphere(countries, 'southeastern')
#	countries_southeast.each do |country|
#		p country.to_s
#	end
#	p countries_southeast.length

	#list countries in Asia with more than 10 political parties 
#	countries_poli = factbook.find_political(countries, 10, "Asia")
#	countries_poli.each do |country|
#		p country.to_s
#	end

	#find top 5 countries with (electric consumption / population)
#	countries_electric = factbook.find_electric_consump_capita(countries, 5)
#	countries_electric.each do |country|
#		p country
#	end

	#find countries with dominant religion "more than" (> percentage of population)"
#	countries_reli_more = factbook.find_religion_more(countries, 80)
#	countries_reli_more.each do |country|
#		p country
#	end

	#find countries with dominant religion "less than" (< percentage of population)
#	countries_reli_less = factbook.find_religion_less(countries, 50)
#	countries_reli_less.each do |country|
#		p country
#	end


	#find landlocked country
#	countries_landlocked = factbook.find_landlocked(countries)
#	countries_landlocked.each do |country|
#		p country
#	end

	#wildcard find countries that speak a certain language
#	countries_language = factbook.find_language(countries, "Korean")
#	countries_language.each do |country|
#		p country
#	end
end

main