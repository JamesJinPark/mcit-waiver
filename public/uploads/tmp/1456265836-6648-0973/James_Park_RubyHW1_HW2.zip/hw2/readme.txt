James Park
CIS 597 - HW2

Java to Ruby - Java translation

This java program was done for a homework assignment for CIT 594.
It was designed to get us to compute the lengths of various 
collatz sequences, with and without memoization, and determine 
various features of the collatz function. 

Collatz function: 

def collatz(n) 
  if (n == 1)
   return 1
  end
  if (n % 2 == 0)
    collatz( n / 2)
  end
  if(n % 2 != 0)
    collatz( 3 * n + 1)
  end
end   

This program also implements the Pair class, which is simply a 
pair of numbers.



Jeopardy and CIA World Factbook

I set up my program where I have two classes, the country class  
and the factbook class.  The country class contains the following 
instance variables:  name, country code, global region, and 
population.  The factbook class contains all functions that will
answer the questions posted by HW2.

1)  For listing countries in South America that are prone to 
earthquakes, I wrote a function that took a list of countries, 
the region where we want to limit our search to, and the country
attribute that we are interested in.  For each country in the 
list, I access the CIA World Factbook's page on the country, and 
use the 'match' function to find the attribute somewhere on the 
webpage.  If the attribute is found, I pushed the country to the 
answers array. 

2)  For finding countries with the lowest elevation, I wrote a 
function that took a list of countries and the global region we 
are interested in searching in.  For each country, I did a regex 
search to find the country's lowest elevation and stored the 
absolute lowest elevation found.  Then I iterated over the 
countries again to find which country's lowest elevation matched 
the absolute lowest elevation.  I returned this country.

3)  For finding all countries in the southeastern hemisphere, I 
wrote a function that took a list of countries and the location 
that we were interested in.  The location would either be, 
Northern, Southern, Western, Eastern, Northwestern, Northeastern,
Southwestern, or Southeastern.  For each country, I did a regex 
search to find the geographic coordinates of the country.  These
coordinates would either have N, S, E, or W.  I matched these N,
S, E, or W, with the location and returned a list of countries 
that match the location.

4)  For finding countries in Asia with more than 10 political
parties, I encountered a problem where the political parties 
did not have a uniform standard or naming convention that could
be used to find all political parties listed on the country page.
I used the most obvious heuristic measure, and found all instances
of the use of "Party" and used the count as the number of political
parties.  Furthermore, since Asia is a larger regional entity than 
what is used on the CIA World Factbook, I counted all regions that 
would count as being in Asia such as the Middle East and Central
Asia. 

5)  To find the countries with the highest electric consumption per
capita, I first found the kWh that the country consumed.  I would 
then divide this number with the population and then put this new
number in a hash table where the key is the country name.  I then
sorted the hash table by the new number and get an array out of it.
FInally, I iterated through the array the limited times that was 
inputted as an argument to get the specified number of top 
countries.

6)  To find countries with dominant religions, I did a regex search
to find the first instance of the listing of religions in the 
Notes and Definitions: Religions; the first instance always list 
the most dominant religion in the country.  I then compared the 
percentage that was listed next to the religion with the number 
that we are interested in.  

7)  To find landlocked countries, I first searched for the list of
countries that bordered the country.  If the length of the list  
was less than 8, it meant that there was only one border country.  
I then did a regex search of "landlock".  Countries that passed 
these two tests, would be pushed onto an array.  

8)  Finally, my wildcard test was to find all countries that speak
a certain language.  For each country, I did a match search to find
whether the language in question is listed in the area of the page
where the list of languages spoken in the country is located. 