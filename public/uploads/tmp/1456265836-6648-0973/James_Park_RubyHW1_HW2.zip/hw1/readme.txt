James Park
CIS 597 - HW1

Part 1

1.  Even if the DNS service stopped working, we'd still be able to surf the web using IP 
 addresses such as http://69.60.7.199.  The DNS service simply translate a lot of human
 readable addresses into machine readable addresses and vice versa.

2. The paypal website should be listening to port 443 because the website uses the 
HTTPS protocol which has the designated port number 443.  http://mysite.com:8000/index 
will use the port 8000 because the port number has been specified in the website.  
The ssh protocol use will use the port 22 as 22 is the port number for the designated ssh 
service.

3.  TCP can be considered to be a better protocol because it creates a reliable datastream 
connection between the server and the client.  This is mainly due to TCP's error checking.
TCP is ideal for accessing the World Wide Web and email services, where the latency inherent 
in error checking is not a major problem.  UDP can be a better protocol when any type of 
latency or jitter is an issue.  Applications such as Voice over IP or streaming media is 
usually better suited for UDP because users will not mind losing a couple packets if the 
latency is kept at a minimum. 

4.  One way to keep state of users is for the server to upload a small piece of data to the
client, or a web cookie to the user's web browser.  Each time the user loads the website, the
browser sends the cookie back to the server to inform the website of the user's previous 
web browsing activities.  Another way to keep state of users is to assign a session ID based
on the users IP address and storing this information in an outside database, unrelated to 
the HTTP protocol.  


Part 2

http://www.cis.upenn.edu/~jamespj/

Part 3

http://www.cis.upenn.edu/~jamespj/calendar.html

